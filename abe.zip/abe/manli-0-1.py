#!/usr/bin/python
# -*- coding:utf-8 -*-
# author:siyuanping
class manli:
    def __init__(self, w, v, c):
        self.number = len(w)  # 数量
        self.w = w  # 重量
        self.v = v  # 价值
        self.c = c  # 背包容量
        self.bestVal = 0  # 最大价值
        self.bestSta = [0 for i in range(10)]  # 保存最终状态(0表示不选，1表示选)

    def force(self):
        """蛮力法求解函数"""
        for i in range(self.number):  # 遍历所有可能结果
            curW = 0  # 当前重量
            curVal = 0  # 当前价值
            curSta = [0 for i in range(self.number)]  # 保存当前状态
            for j in range(i, self.number):
                if curW + self.w[j] <= self.c:
                    # 如果满足条件,加进背包
                    curW += self.w[j]
                    curVal += self.v[j]
                    curSta[j] = 1
                if curVal >= self.bestVal:
                    # 更新最优解状态
                    self.bestVal = curVal
                    self.bestSta = curSta

    def solution(self):
        """输出"""
        self.force()
        print("最优解状态：")
        print(self.bestSta)
        print("最大价值为：", self.bestVal)
        print("")

if __name__ == '__main__':
    goods = manli((6, 5, 4, 1, 2, 3, 9, 8, 7), (1, 2, 3, 7, 8, 9, 6, 5, 4), 20)
    # 输出信息
    print("蛮力法解决0-1背包问题:")
    goods.solution()
