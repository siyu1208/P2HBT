#!/usr/bin/python
# -*- coding:utf-8 -*-
# author:siyuanping
class dongtaiguihua:

    def __init__(self, w, v, c):
        self.number = len(w)  # 数量
        self.w = w  # 重量
        self.v = v  # 价值
        self.c = c  # 背包容量
        self.bestVal = 0  # 最大价值
        self.bestSta = [0 for i in range(10)]  # 保存最终状态(0表示不选，1表示选)
        self.t = [[0 for i in range(self.c + 1)] for i in range(self.number + 1)]  # 保存动态规划表

    def table(self):
        """动态规划表填写"""
        for i in range(1, self.number + 1):
            for j in range(i, self.c + 1):
                self.t[i][j] = self.t[i - 1][j]
                # 若背包还有容量，遍历前一个状态考虑是否置换
                if j >= self.w[i - 1] and self.t[i][j] < self.t[i - 1][j - self.w[i - 1]] + \
                        self.v[i - 1]:
                    self.t[i][j] = self.t[i - 1][j - self.w[i - 1]] + self.v[i - 1]
        for x in self.t:
            # 动态规划表的打印输出
            print(x)
    def solution(self):
        print("规划表：")
        self.table()
        j = self.c
        for i in range(self.number, 0, -1):
            if self.t[i][j] > self.t[i - 1][j]:
                self.bestSta[i - 1] = 1
                j -= self.w[i - 1]
        print("动态规划法最优解：")
        print(self.bestSta)
        print("最大价值为：", self.t[self.number][self.c])

if __name__ == '__main__':
        goods = dongtaiguihua((6, 5, 4, 1, 2, 3, 9, 8, 7), (1, 2, 3, 7, 8, 9, 6, 5, 4), 20)
        # 输出信息
        print("动态规划法解决0-1背包问题:")
        goods.solution()


