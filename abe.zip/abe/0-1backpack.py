#!/usr/bin/python
# -*- coding:utf-8 -*-
# author:xujinshan361@163.com

import queue
import math

class Goods:
    """物品信息类 """

    def __init__(self, weight, value, capacity):
        self.number = len(weight)  # 物品数量
        self.weight = weight  # 物品重量
        self.value = value  # 物品价值
        self.capacity = capacity  # 背包容量

    def show(self):
        print("算法设计大作业--(四种方法解决01背包问题)")
        print("背包信息")
        print("物品序号：", [i for i in range(goods.number)])
        print("物品价值：", self.value)
        print("物品重量：", self.weight)
        print("背包容量：", self.capacity)
        print("说明：四种方法显示的最优解状态：0表示不装入，1表示装入。")


class Brute_Force_Method:
    """蛮力法求解"""

    def __init__(self, goods):
        """初始化"""
        self.goods = goods  # 传入goods信息
        self.bestValue = 0  # 保存最终最大价值
        self.bestStatus = [0 for i in range(10)]  # 保存最终状态(0表示不选，1表示选)

    def force(self):
        """蛮力法求解函数"""
        for i in range(self.goods.number):  # 遍历所有可能结果
            currentWeight = 0  # 当前状态重量
            currentValue = 0  # 当前状态价值
            currentStatus = [0 for i in range(self.goods.number)]  # 保存当前状态
            for j in range(i, self.goods.number):
                if currentWeight + self.goods.weight[j] <= self.goods.capacity:
                    # 如果满足添加物品状态则添加进背包
                    currentWeight += self.goods.weight[j]
                    currentValue += self.goods.value[j]
                    currentStatus[j] = 1
                if currentValue >= self.bestValue:
                    # 满足条件更新最优解状态
                    self.bestValue = currentValue
                    self.bestStatus = currentStatus

    def solution(self):
        """最终结果输出展示"""
        print("*****蛮力法求解*****")
        self.force()  # 求解函数
        print("蛮力法最优解状态：")
        print(self.bestStatus)
        print("最优解的最大价值为：", self.bestValue)
        print("")


class Dynamic_Programming_Method:
    """动态规划法求解"""

    def __init__(self, goods):
        self.goods = goods  # 保存goods信息
        self.bestValue = 0  # 保存最大价值
        self.bestStatus = [0 for i in range(self.goods.number)]  # 保存最优解状态信息
        self.v = [[0 for i in range(self.goods.capacity + 1)] for i in range(self.goods.number + 1)]  # 保存动态规划表

    def fillForm(self):
        """动态规划表填写"""
        for i in range(1, self.goods.number + 1):
            for j in range(i, self.goods.capacity + 1):
                self.v[i][j] = self.v[i - 1][j]
                # 背包总容量够放当前物体，遍历前一个状态考虑是否置换
                if j >= self.goods.weight[i - 1] and self.v[i][j] < self.v[i - 1][j - self.goods.weight[i - 1]] + \
                        self.goods.value[i - 1]:
                    self.v[i][j] = self.v[i - 1][j - self.goods.weight[i - 1]] + self.goods.value[i - 1]
        for x in self.v:
            # 输出动态规划表
            print(x)

    def solution(self):
        print("*****动态规划法求解******")
        print("动态规划表为：")
        self.fillForm()

        # 打印最优解结果(0表示不装入，1表示装入)
        j = self.goods.capacity
        for i in range(self.goods.number, 0, -1):
            if self.v[i][j] > self.v[i - 1][j]:
                self.bestStatus[i - 1] = 1
                j -= self.goods.weight[i - 1]
        print("动态规划法最优解状态：")
        print(self.bestStatus)
        print("最大价值为：", self.v[self.goods.number][self.goods.capacity])
        print("")


class Backtracking_Method:
    """回溯法求解"""

    def __init__(self, goods):
        self.goods = goods  # 保存goods信息
        self.currentWeight = 0  # 保存当前状态最大重量
        self.currentValue = 0  # 保存当前状态最优解
        self.bestValue = 0  # 保存最优解
        self.bestStatus = [0 for i in range(self.goods.number)]  # 保存最优状态
        self.currentStatus = [0 for i in range(self.goods.number)]  # 保存当前状态

    def backtrack(self, i):
        """回溯求解函数"""
        if i >= self.goods.number:
            if self.bestValue < self.currentValue:
                self.bestValue = self.currentValue
                self.bestStatus = self.currentStatus
        else:
            if self.currentWeight + self.goods.weight[i] <= self.goods.capacity:
                self.currentStatus[i] = 1
                self.currentWeight += self.goods.weight[i]
                self.currentValue += self.goods.value[i]
                self.backtrack(i + 1)
                self.currentWeight -= self.goods.weight[i]
                self.currentValue -= self.goods.value[i]
                self.currentStatus[i] = 0
            self.backtrack(i + 1)

    def solution(self):
        print("*****回溯法求解*****")
        print("回溯最优解状态：")
        print(self.bestStatus)
        print("最优解的最大价值：", self.bestValue)
        print("")


class Brach_And_bound_Method:
    """分支界限法求解"""

    def __init__(self, goods):
        self.goods = goods
        self.bestValue = 0

    def brach(self):
        """分支界限法求解函数"""
        vecLen = 2 ** (self.goods.number + 1) - 1
        vecValue = [0 for i in range(vecLen)]
        vecWeight = [0 for i in range(vecLen)]
        vecWeight[0] = self.goods.capacity
        que = queue.Queue()
        que.put(0)
        best = 0
        while not que.empty():
            current = que.get()
            level = int(math.log(current + 1, 2))
            if vecValue[current] > vecValue[best]:
                best = current
            left = 2 * current + 1
            right = 2 * current + 2
            if left < vecLen and vecWeight[current] - self.goods.weight[level] >= 0:
                vecValue[left] = int(vecValue[current] + self.goods.value[level])
                vecWeight[left] = vecWeight[current] - self.goods.weight[level]
                que.put(left)
            if right < vecLen and sum(self.goods.value[level + 1:self.goods.number]) + vecValue[current] >= vecValue[
                best]:
                vecValue[right] = vecValue[current]
                vecWeight[right] = vecWeight[current]
                que.put(right)
        self.bestValue = vecValue[best]

    def solution(self):
        self.brach()
        print("*****分支界限法求解*****")
        print("最优解的最大价值", self.bestValue)


if __name__ == '__main__':
    goods = Goods((0, 6, 5, 4, 1, 2, 3, 9, 8, 7), (0, 1, 2, 3, 7, 8, 9, 6, 5, 4), 20)
    # 输出信息
    goods.show()
    """测试四种算法"""
    """测试蛮力法"""
    Brute_Force_Method(goods).solution()
    """测试动态规划法"""
    Dynamic_Programming_Method(goods).solution()
    """测试回溯法"""
    Backtracking_Method(goods).solution()
    """测试分支界限法"""
    Brach_And_bound_Method(goods).solution()
