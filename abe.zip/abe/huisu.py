#!/usr/bin/python
# -*- coding:utf-8 -*-
# author:siyuanping
class huisu:
    def __init__(self, w, v, c):
        self.number = len(w)  # 数量
        self.w = w  # 重量
        self.v = v  # 价值
        self.c = c  # 背包容量
        self.curw = 0  # 当前最大重量
        self.curv = 0  # 当前最优解
        self.bestv = 0  # 最优解
        self.bestSta = [0 for i in range(self.number)]  # 最优状态
        self.curSta = [0 for i in range(self.number)]  # 当前状态

    def backtrack(self, i):
        if i >= self.number:
            if self.bestv < self.curv:
                self.bestv = self.curv
                self.bestSta = self.curSta[:]
        else:
            if self.curw + self.w[i] <= self.c:
                self.curSta[i] = 1
                self.curw += self.w[i]
                self.curv += self.v[i]
                self.backtrack(i + 1)
                self.curw -= self.w[i]
                self.curv -= self.v[i]
            self.curSta[i] = 0
            self.backtrack(i + 1)
    def show(self):
        print("回溯法解决0-1背包问题:")
    def solution(self):
        self.backtrack(0)
        print("回溯法最优解：")
        print(self.bestSta)
        print("回溯法最优解的最大价值：", self.bestv)
        print("")

if __name__ == '__main__':
    goods = huisu((0, 6, 5, 4, 1, 2, 3, 9, 8, 7), (0, 1, 2, 3, 7, 8, 9, 6, 5, 4), 20)
    # 输出信息
    goods.show()
    goods.solution()
