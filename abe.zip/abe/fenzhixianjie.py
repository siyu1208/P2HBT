#!/usr/bin/python
# -*- coding:utf-8 -*-
# author:siyuanping
import queue
import math
class fenzhixianjie:
    """分支限界法求解"""
    def __init__(self, w, v, c):
        self.number = len(w)  # 数量
        self.w = w  # 重量
        self.v = v  # 价值
        self.c = c  # 背包容量
        self.bestValue = 0

    def brach(self):
        vLen = 2 ** (self.number + 1) - 1
        vValue = [0 for i in range(vLen)]
        vW = [0 for i in range(vLen)]
        vW[0] = self.c
        que = queue.Queue()
        que.put(0)
        best = 0
        while not que.empty():
            current = que.get()
            level = int(math.log(current + 1, 2))
            if vValue[current] > vValue[best]:
                best = current
            left = 2 * current + 1
            right = 2 * current + 2
            if left < vLen and vW[current] - self.w[level] >= 0:
                vValue[left] = int(vValue[current] + self.v[level])
                vW[left] = vW[current] - self.w[level]
                que.put(left)
            if right < vLen and sum(self.v[level + 1:self.number]) + vValue[current] >= vValue[
                best]:
                vValue[right] = vValue[current]
                vW[right] = vW[current]
                que.put(right)
        self.bestValue = vValue[best]

    def show(self):
        print("分支限界法解决0-1背包问题:")

    def solution(self):
        self.brach()
        print("最优解的最大价值", self.bestValue)

if __name__ == '__main__':
    goods = fenzhixianjie((0, 6, 5, 4, 1, 2, 3, 9, 8, 7), (0, 1, 2, 3, 7, 8, 9, 6, 5, 4), 20)
    # 输出信息
    goods.show()
    goods.solution()

